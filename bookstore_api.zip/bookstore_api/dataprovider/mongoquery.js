const insert = (collection, data) => {
    return new Promise((resolve, reject) => {
        var schema = require(`../model/${collection}`);
        var model = new schema(data);
        model.save((err, saved) => {
            if (err) {
                return reject(err);
            }
            return resolve(true)
        })
    })
}


const findone =(collection,query)=>{
		return new Promise((resolve,reject)=>{
			var model = require(`../model/${collection}`);

			model.findOne(query).then((searchResult)=>{

				return resolve(searchResult);
			})
			.catch(err =>{
				return reject(err);
			})
		})
}

const find = (collection,query)=>{
	return new Promise((resolve,reject)=>{
		var model = require(`../model/${collection}`);

		model.find(query).then((searchResult)=>{
			return resolve(searchResult);
		})
		.catch(err =>{
			return reject(err);
		})
	})
}

const findoneanddelete = (collection,query)=>{
	return new Promise((resolve,reject)=>{
		var model = require(`../model/${collection}`);

		model.findOneAndDelete(query).then((deleteItem)=>{
			return resolve (deleteItem);
		})
		.catch(err =>{
			return reject(err);
		})
	})
}

const deletemany =(collection,query)=>{
	return new Promise((resolve,reject)=>{
		model.deleteOne(query).then((deleteItem)=>{
			return resolve (deleteItem);
		})
		.catch(err =>{
			return reject(err);
		})
	})
}
function updateone(collection, query, updatequery, output, upsert) {

    return new Promise((resolve, reject) => {
        var model = require(`./model/${collection}`);
        model.updateOne(query, updatequery, { new: output, upsert: upsert })
            .then(updateresult => {
                return resolve(updateresult);
            })
            .catch(err => {
                return reject(err)
            })
    })
}

function bcryptcompare(comparepassword,originalpassword){
	return new Promise((resolve,reject)=>{
		bcrypt = require('bcrypt');
		bcrypt.compare(comparepassword,originalpassword).then(result=>{
			return resolve(result)
		})
		.catch(err =>{
			return reject(err);
		})
	})
}


module.exports ={insert,
	findone,
	updateone,
	bcryptcompare,
	find,
	deletemany,
	findoneanddelete,


}

