const passport = require('passport');

var bcrypt = require('bcrypt');
var LocalStrategy   = require('passport-local').Strategy;
var query = require('./dataprovider/mongoquery');
var Person = require('./model/Person');
var enums = require('./util/enums');
var FacebookStrategy = require('passport-facebook').Strategy;

passport.use(new LocalStrategy({
     userfield:"username",
     passwordfield:"password"
},
 function(username,password,done){

            return query.findone("Person",{username : username, status :"Active"}).then(result =>{

                    if(!result){
                            return done(null,false,{message : "incorrect username or password"});
                    }  

                    if(result){
                        query.bcryptcompare(password,result.password).then(output =>{
                            console.log(output)
                            if(output){
                                if(result.failedlogin < 3){
                                    result.failedlogin = 0 ;
                                    result.failedlogintime = null;
                                
                                     query.insert("Person",result).then(loginsuccess=>{
                                        console.log(loginsuccess);
                                        //return responseHandler(res, enums.RESOURCE_CREATED_SUCESSFULLY_HTTP_CODE, enums.RESOURCE_CREATED_SUCESSFULLY, "Success",loginsuccess, null);
                                    }).catch(err =>{
                                       console.log(err)
                                    })

                                    return done(null,{result},{message:"logged in successfully"});
                                }

                                else{
                                    done(err,false,{message : "Logged in blocked"});
                                }
                            }

                            else{
                                    result.failedlogin = ++failedlogin;
                                    result.failedlogintime = new Date();

                                    if(result.failedlogin > 3){
                                        if(user.failedlogintime.getTime() < (user.failedlogintime.getTime() + 24*60*60)){
                                            return done(err,false , {message: 'login is blocked'});
                                        }

                                    }

                                    else{
                                        query.insert("Person",result).then(updated=>{
                                        return responseHandler(res, enums.RESOURCE_CREATED_SUCESSFULLY_HTTP_CODE, enums.RESOURCE_CREATED_SUCESSFULLY, "Success",updated, null);
                                    }).catch(err =>{
                                       console.log(err);
                                    })
                                    }
                            }
                        })
                    }
            }).catch(err =>{
                console.log(err);
            })
       }
            
 ))
 
passport.use(new FacebookStrategy({
     clientID:"338946653290163",
     clientSecret:"ddce6c8e83b10fdce35772181dbcf6b3",
     callbackURL:"http://localhost:4001/auth/facebook/callback"
 },
        function(accesstoken,refreshtoken,profile,done){
            console.log("accesstoken : ",accesstoken);
            console.log('refreshtoken ',refreshtoken);
            console.log("profile: " ,profile.id);
          // return done(null,accesstoken)
                    // res.send('done');
                var Person =require('./model/Person');
              Person.findOne({'facebookid':profile.id},(err,users)=>{
               if(err){
                   console.log(err);
                   return done(err)
                }

                console.log("234",users);

                if(!users){
                   
                    var newfbuser = new Person({
                        facebookid:profile.id,
                        status : "Active"

                    });
                    console.log("100")
                    newfbuser.save(function(err){
                        if(err){
                            console.log(err);
                           return done(err)
                        }
                        console.log(newfbuser);
                        
                        return done(null,newfbuser);
                    })
                    console.log("110")
                }

                   })
           }))
           
        


function responseHandler(res,code,message,result,data,err){
    res.status(code).json({
        code:code,
        message:message,
        result:result,
        data:data,
        err : err
    })
}


module.exports = passport

