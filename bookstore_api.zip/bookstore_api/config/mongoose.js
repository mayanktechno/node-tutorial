var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/multiple',{ useNewUrlParser: true },(err)=>{

	if(err){
		console.log('connection error');
	}

	console.log('connected');
});

module.exports=mongoose;

