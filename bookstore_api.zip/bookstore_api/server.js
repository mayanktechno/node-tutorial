var express = require('express');
var cors = require('cors');
var app = express();
var passport=require('passport');

var bodyparser = require('body-parser');
var mongoose = require('./config/mongoose');
var user = require('./controller/Usercontroller');
var routes = require('./routes')
app.use(bodyparser.json());


passport.serializeUser(function(user, done) {
	done(null, user);
  });
  
  passport.deserializeUser(function(user, done) {
	done(null, user);
  });
app.use(cors());
app.use(passport.initialize());
app.use(passport.session());

app.use('/',routes);
var cron = require('node-cron');
var task = cron.schedule('* * 23 * * *', () => {              //0 0 23 * * = 24 hrs at night
  query.deletemany("Person",{status:"inActive"}).then(result =>{
    return responseHandler(res,enums.RESOURCE_DELETE_SUCCESSFULLY_HTTP_CODE ,enums.RESOURCE_DELETE_SUCCESSFULLY,"Success","result",null);
  })
  .catch(err =>{
    return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null);
  })
  })
app.listen(4001,()=>{
	console.log('connected to port 4001');
});



function responseHandler(res,code,message,result,data,err){
	res.status(code).json({
		code:code,
		message:message,
		result:result,
		data:data,
		err : err
	})
}
