var mongoose = require('mongoose');

Schema = mongoose.Schema;

var storyschema = new Schema({

	seller :{type:String},
	category:	[{
    name : String,
   subcategories  : [{
   book : String,
    author: String,
	price : Number
     }]
}]
		

		
})

var Story = mongoose.model('Story',storyschema);

module.exports = Story