
var mongoose = require('mongoose');

var Schema =mongoose.Schema;

var bcrypt = require('bcrypt');

var personschema = new Schema({

	name:String,
	address:String,
	mobile:{
		type:Number,
		//required:true
	},
	facebookid:{type:String},

	email :{
		type:String,
		//required:true
	},

	status :{
		type:String,
		default :'inActive'
	},
	vcode:{
		type:String
	},
	username :{
        //required:true,
        unique:true,
        type:String
    },
    password:{
        //required:true,
        type:String
	},
	
	failedlogin:{
		type:Number,
		default:0
	},
	createdAt:{
		type:Date,
		default:Date.now
	},
	failedlogintime:{
		type:Date,
		default: null
	},

	resetpassswordtoken:{type:String},
	resettokenexpires:{type:String}
})

var Person = mongoose.model('Person',personschema);


module.exports = Person;