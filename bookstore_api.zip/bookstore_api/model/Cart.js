var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var cartschema = new Schema({
	
	name:{type:Schema.Types.ObjectId, ref:'Person'},
	book :[{type:Schema.Types.ObjectId , ref : 'Story'}],

	quantity:{type:Number,default: 1},
	


})

var Cart = mongoose.model('Cart',cartschema);

module.exports = Cart