var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var orderschema = new Schema({
	
	customername:{type:String},
	address :{type:String},
	mobile:{type:String},
	email:{type:String},
	book:{type:String},
	author:{type:String},
	price:{type:Number},
	quantity:{type:Number},
	billedamount:{type:Number}


})

var Order = mongoose.model('Order',orderschema);

module.exports = Order