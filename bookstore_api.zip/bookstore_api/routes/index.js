var express = require('express');
var router = express.Router();
var passport = require('passport');
var cntl = require('../controller/Usercontroller')
var bookcontroller = require('../controller/bookcontroller');
var cartcontroller = require('../controller/cartcontroller');

router.get('/',cntl.root);
router.post('/insert',cntl.inserting);
router.get('/verifymail/:username/code/:vcode',cntl.verifymail);
//router.get('/getdata',cntl.getdata)
router.post('/login',cntl.login);
router.post('/forget',cntl.forget);
router.post('/reset/:token',cntl.confirmPassword);
router.get('/auth/facebook',
  passport.authenticate('facebook'));

router.get('/auth/facebook/callback',
  passport.authenticate('facebook', { failureRedirect: '/login' }),
  function(req, res) {
    // Successful authentication, redirect home.
    res.redirect('/');
  });



//admin routes
router.post('/bookinsert',bookcontroller.insertbook);
router.get('/getbook',bookcontroller.getbook);
router.get('/getallbook',bookcontroller.getallbook);
router.post('/deletebook',bookcontroller.deletebook);

router.post('/addtocart/:storyid',cartcontroller.productcart);
router.get('/getcart',cartcontroller.getcart);
router.get('/placeorder/:cartid',cartcontroller.orderplace);
    									router.post('/payment/:billedamount',cartcontroller.payment);
module.exports = router;