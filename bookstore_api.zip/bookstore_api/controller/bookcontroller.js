var query = require('../dataprovider/mongoquery');
var enums = require('../util/enums')

module.exports.insertbook = (req,res)=>{

var add = {

	seller :req.body.seller,

	category:[{
    name     : req.body.category[0].name,
     subcategories  : [{
     	

      console.error('saved img to mongo');

    book : req.body.category[0].subcategories[0].book,
    author: req.body.category[0].subcategories[0].author,
	price : req.body.category[0].subcategories[0].price
     }]
}]
				
}
	var dataToInsert=add
		console.log(dataToInsert);
	query.insert("Story",dataToInsert).then(saved=>{
		 return responseHandler(res, enums.RESOURCE_CREATED_SUCESSFULLY_HTTP_CODE, enums.RESOURCE_CREATED_SUCESSFULLY, "Success",saved, null);
	}).catch(err =>{
			return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null);
	})
}

module.exports.getbook =(req,res)=>{
	query.findone("Story",{"category.name" : req.body.category[0].name}).then(result =>{
		console.log(result);
		return responseHandler(res,enums.RESOURCE_ALREADY_EXISTS_HTTP_CODE,enums.RESOURCE_ALREADY_EXISTS ,"success",result,null);
	})
	.catch(err=>{
		return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null);
	})
}

module.exports.getallbook =(req,res)=>{

	query.find("Story",{}).then(result =>{
		return responseHandler(res,enums.RESOURCE_ALREADY_EXISTS_HTTP_CODE,enums.RESOURCE_ALREADY_EXISTS ,"success",result,null);
	})
	.catch(err=>{
		return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null);
	})
}

module.exports.deletebook =(req,res)=>{
	query.findoneanddelete("Story",{"category.subcategories.book": req.body.category[0].subcategories[0].book}).then(result =>{
		return responseHandler(res,enums.RESOURCE_DELETE_SUCCESSFULLY_HTTP_CODE ,enums.RESOURCE_DELETE_SUCCESSFULLY,"success",result,null);
	})
	.catch(err =>{
		return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null)
	})
}

function responseHandler(res,code,message,result,data,err){
	res.status(code).json({
		code:code,
		message:message,
		result:result,
		data:data,
		err : err
	})
}
