var query = require('../dataprovider/mongoquery');
var jwtDecode = require('jwt-decode');
var enums = require('../util/enums')

module.exports.productcart =(req,res)=>{
	console.log(req.params);
 var token = req.headers.authorization.split(' ')[1];
 var decryptToken = jwtDecode(token);
 //console.log(decryptToken);

 			name =	decryptToken.result._id;
 			book = req.params.storyid
 			quantity = req.params.quantity;

 			dataToinsert = {
 			name,
 			book
 			}

	console.log(dataToinsert);

	query.insert('Cart',dataToinsert).then(item =>{

		 return responseHandler(res, enums.RESOURCE_CREATED_SUCESSFULLY_HTTP_CODE, enums.RESOURCE_CREATED_SUCESSFULLY, "Success",item, null);
			 
	}).catch(err =>{
			return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null);
	})	

}

module.exports.getcart = (req,res)=>{

	var Cart = require('../model/Cart');
	Cart.find({}).populate('name').populate('book').exec((err,result )=>{
		if(err){
			console.log(err);
		}
		console.log(result);
		return res.send(result);

	})
}

module.exports.orderplace =(req,res)=>{
	var Cart = require('../model/Cart');
		Cart.findOne({_id:req.params.cartid}).populate('book').populate('name').exec((err,result)=>{
				if(err){
					console.log(err);
				}

				customername = result.name.name;
				address = result.name.address;
				mobile = result.name.mobile;
				email = result.name.email;
				book=result.book[0].category[0].subcategories[0].book;
				author=result.book[0].category[0].subcategories[0].author;
				price = result.book[0].category[0].subcategories[0].price;
				quantity=result.quantity;
				billedamount =result.book[0].category[0].subcategories[0].price * result.quantity;
				orderdata={
					customername,
					address,
					mobile,
					email,
					book,
					author,
					price,
					quantity,
					billedamount
				}
				console.log(orderdata);
		query.insert("Order",orderdata).then(order =>{
			 return responseHandler(res, enums.RESOURCE_CREATED_SUCESSFULLY_HTTP_CODE, enums.RESOURCE_CREATED_SUCESSFULLY, "Success",order, null);
		}).catch(err => {
        	console.log(err)
           responseHandler(res, enums.INTERNAL_SERVER_ERROR_HTTP_CODE, enums.INTERNAL_SERVER_ERROR, "Failed", null, null);
        })
				 console.log(result);
		})
}


module.exports.payment = (req,res)=>{

	const stripe = require('stripe')('sk_test_vyDzUJND1AHiOjZj1oOi5EIi0015pUNCh5');

	console.log(req.params);
 let amount = req.params.billedamount; 
 let mail = req.body.email;

 console.log(mail);
   		
    // create a customer 
    stripe.customers.create({
        email: mail, // customer email, which user need to enter while making payment
        source: "tok_visa"             // token for the given card 
    }	
)
    .then(customer =>
        stripe.charges.create({ // charge the customer
        amount,
        description: "Sample Charge",
            currency: "inr",
            customer: customer.id
        }))

    .then(charge => {
    	console.log(charge);
    	res.send(charge);
    })
};

/*Publishable key
pk_test_HG0vKfuujCNRPUTayvMGBlmw00oK7VS9Uw

Secret key
sk_test_vyDzUJND1AHiOjZj1oOi5EIi0015pUNCh5

*/

function responseHandler(res,code,message,result,data,err){
	res.status(code).json({
		code:code,
		message:message,
		result:result,
		data:data,
		err : err
	})
}
