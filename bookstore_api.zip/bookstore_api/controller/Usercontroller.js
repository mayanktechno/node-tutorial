var Person = require('../model/Person');
var Story = require('../model/Story');
var mongoose = require('mongoose');
var query = require('../dataprovider/mongoquery');
var enums = require('../util/enums');
var randToken = require('rand-token');
var bcrypt = require('bcrypt');
var passport = require('passport');
var nodemailer = require('nodemailer');
require('../passport');
var async = require('async');
var crypto = require('crypto');
var jwt = require('jsonwebtoken');


module.exports.root = (req,res)=>{

     res.send("!!!...WELCOME TO THE BOOKSTORE ...!!!");
}
	module.exports.inserting = (req,res)=>{

	query.findone("Person",{username:req.body.username}).then(result=>{
		if(result){
				return responseHandler(res,enums.RESOURCE_ALREADY_EXISTS_HTTP_CODE,enums.RESOURCE_ALREADY_EXISTS,"failed",result,null);
	}
	
	else{
var saltRound = 10;
bcrypt.hash(req.body.password,saltRound,(err,hash)=>{
	if(err){
		console.log(err);
	}

	name=req.body.name;
	address=req.body.address;
	mobile=req.body.mobile;
	email =req.body.email;
	vcode=randToken.generate(8);
	username =req.body.username;
    password=hash

	var dataToInsert = {
	
	name,
	address,
	mobile,
	email ,
	vcode,
	username,
	password
   }

   //console.log(dataToInsert);
	query.insert("Person", dataToInsert).then(person => {
		console.log(person)
		if(person){
			 var smtpTransport = nodemailer.createTransport({

                service:'gmail',

                auth:{
                    user:'mkkush12@gmail.com',
                    pass:'mkkush12'
                }

            });
            var mailOptions ={

                to:email,

                from:'mkkush12@gmail.com',

                subject : 'node registration mail',
                text :'Hi , You are getting this because you suucessfully registered to the node app. your click on the link for the vererification.'+ "http://"+req.headers.host+"/verifymail/"+username+"/code/"+vcode+"\n\n"
            };
                                                                                                                                                                                                                      
           console.log("my mail option",mailOptions)
                
          smtpTransport.sendMail(mailOptions,(err,info)=>{

                    if(err){
                        console.log(err);
                    }
                    else {
                          console.log('Email sent: ' + info.response);
                }

                })
            return responseHandler(res, enums.RESOURCE_CREATED_SUCESSFULLY_HTTP_CODE, enums.RESOURCE_CREATED_SUCESSFULLY, "Success",person, null);
		}
        }).catch(err => {
        	console.log(err)
            return responseHandler(res, enums.INTERNAL_SERVER_ERROR_HTTP_CODE, enums.INTERNAL_SERVER_ERROR, "Failed", null, null);
        })
    })}
})
        .catch(err=>{
		return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,null);
	})

}




module.exports.verifymail = (req,res)=>{

    var username =req.params.username;
    var vcode = req.params.vcode;

    query.findone('Person',{username:username}).then(result=>{

    	 if(result){
            if(result.createdAt > new Date().getTime() - (1 * 24 * 60 * 60 * 1000)){
                console.log("result.createdAt ",result.createdAt);
               
                if(result.vcode === vcode){
                    console.log("User is Verified");

                    result.status ="Active";
                    result.save().then(statusupdated=>{
                        console.log("User is Active");
                        return res.json(statusupdated,{message: "user is verified"});
                        
                    })

   				 }
          }
    			else{
    				return res.json({message:"verification code not match"})
    			}
}
		else{
			res.send({message : " User is not Found"})
		}
})			
    		.catch(err =>{

			res.send("verification Link expired ");
})

}

module.exports.login = function (req, res, next) {
    console.log(req.body);
passport.authenticate('local', {session: false}, (err, user, info) => {
    //console.log(err);
console.log("USER" , user)

        if (err || !user) {
            return res.status(400).json({
                message: 'Something is not right',

            });
        }
       req.login(user, {session: false}, (err) => {
           if (err) {
               res.send(err);
           }
          
           const token = jwt.sign(user,'mayank-secret');

           console.log("token : " ,token);  
  
            return res.json({user, token});          
        });
    })(req, res);
} 


function responseHandler(res,code,message,result,data,err){
  res.status(code).json({
    code:code,
    message:message,
    result:result,
    data:data,
    err : err
  })
}




module.exports.forget=(req,res,next)=>{

  async.waterfall([

      function(done){

            crypto.randomBytes(20,(err,buf)=>{

                var token =buf.toString('hex');
                    console.log("token for forget: ",token);
                done(err,token);
            })
        },

        function(token,done){
            query.findone("Person",{email:req.body.email}).then(user =>{
              if(!user){
                console.log("no user found with this email");
                return responseHandler(res,enums.RESOURCE_NOT_FOUND_HTTP_CODE,enums.RESOURCE_NOT_FOUND,"failed",null,null);
              }
              if(user){

                user.resetpassswordtoken = token
                user.resetpasswordexpires = Date.now();

                   user.save((err)=>{

                    if(err){
                        console.log(err);
                    }

                    console.log('user is saved');
                    done(err,token,user);
                })
              }
            })
            .catch(err =>{
              return responseHandler(res,enums.INTERNAL_SERVER_ERROR_HTTP_CODE,enums.INTERNAL_SERVER_ERROR,"failed",null,err);
            })
        },

        function(token,user,done){

            console.log('user in nodemailer',user)
            var smtpTransport = nodemailer.createTransport({

                service:'gmail',

                auth:{
                    user:'mkkush12@gmail.com',
                    pass:'mkkush12'
                }

            });

            var mailOptions ={

                to:user.email,

                from:'mkkush12@gmail.com',

                subject : 'node forget password mail',
                text :'you are getting this mail because someone has made the request for changing the password '+
                'please check the link below for the changing the password '+
                "http://"+req.headers.host+"/reset/"+token+"\n\n"+
                'is you did not made the attempt for changing password  then ignore this email.'
            };

           console.log("my mail option",mailOptions)
                
          smtpTransport.sendMail(mailOptions,(err,info)=>{

                    if(err){
                        console.log(err);
                    }
                    else {
                          console.log('Email sent: ' + info.response);
                }

                    done(err,done);
                })
        }

        ])
    
}


module.exports.confirmPassword = (req,res,next)=>{

async.waterfall([

function(done){
    var Person = require('../model/Person')
    console.log("params confirm : ",req.params.token);
    Person.findOne({resetpassswordtoken:req.params.token},(err,user)=>{

        console.log('my user :' ,user);

        if(err){
            console.log(err);

        }

        if(!user){
            console.log("password reset token is invalid or expires ");

            res.status(400).send('reset token is invalid');
        }

        if(req.body.password===req.body.confirm){

             if(req.body.password.length < 6){
        console.log('password must be more than 6 character');

        res.status(400).send('password must be more than 6 character ');
    }
        else{
            const saltRound =10;
            bcrypt.hash(req.body.password,saltRound,(err,hash)=>{
           
            if(err){
            console.log(err);
                }

            console.log("hash password : " ,hash);


          Person.updateOne({resetpassswordtoken:req.params.token},{$set:{password:hash}},{new:true},(err,result)=>{
            

                 console.log("result : ",result);

                    user.resetpassswordtoken=undefined;
                    user.resetpasswordexpires=undefined;

                    console.log("updated user :" , user.resetpassswordtoken);

                    res.send(user);

                user.save((err)=>{

                    if(err){
                        console.log(err);
                    }

                    
                    done(err,user,result);

                })
        })
            
            
        })}
}
        else{
            console.log('passsword does not match');

            res.send('unmatched password');
        }
    })
},
        function(user,done){
              
        
            var smtpTransport = nodemailer.createTransport({

                service:'gmail',

                auth:{
                    user:'mkkush12@gmail.com',
                    pass:'mkkush12'
                }

            });

            var mailOptions ={

                to:user.email,

                from:'mkkush12@gmail.com',

                subject : 'node confirmed password mail',
                text :'This is mail is regarding the confirmation of your request that you have just change your password.'
            };

           console.log("my mail option",mailOptions)
                
          smtpTransport.sendMail(mailOptions,(err,info)=>{

                    if(err){
                        console.log(err);
                    }
                    else {
                          console.log('Email sent: ' + info.response);
                }

                    done(err,done);
                })
        }

    ])
}


//module.exports.changepassword =
 










    


// module.exports.getdata =(req,res)=>{

// 	Story.findOne({title:req.body.title}).populate('author').exec((err,story)=>{

// 		//Story.findOne ({title:req.body.title}).populate('author','age').exec((err,story)=>{//2nd field in populate is for selectinh the particular field of that authpr linking person schema 
// 		if(err){
// 			console.log(err);
// 		}

// 		console.log(story);

// 		console.log('story author link tpo person :',story.author[0].name);				

// 		console.log(story.author[0].age);
// })

	
	
// 		Story.findOne({title:req.body.title}).populate('fans').populate('author').exec((err,result)=>{

// 				if(err){
// 					console.log(err);
// 				}	

// 				console.log(result);

// 				console.log('fans age : ', result.fans[0].age);

// 				console.log('author name :  ', result.author[0].name)
// 		})

		
// /*
// Story.findOne({title:req.body.title}).populate({path : 'fans' , select:'name'})
// 									.populate({path:'fans', select:'age'}).exec((err,result)=>{

// 							if(err){
// 								console.log(err);
// 							}

// 							console.log(result);

// 				console.log('fan name : ', result.fans[0].name);
// 				console.log('fan age : ',result.fans[0].age);							
// 		})



// /*Story.findOne({title:req.body.title}).populate({path:'fans', select:'age'})
// 										.populate({path : 'fans' , select:'name'})
// 									.exec((err,result)=>{

// 							if(err){
// 								console.log(err);
// 							}

// 							console.log(result);

// 				console.log('fan name : ', result.fans[0].name);
// 				console.log('fan age : ',result.fans[0].age);							
// 		})
// */

// }